#####################################################################################
## Author: Sina Rueeger [sina *.* rueger *a*t* unil *.* ch]
## Project: 
##        
## Time-stamp: <[A_prep_data.R] by SR Wed 29/01/2014 11:21 (CET)>
##
## Description:
## 
##
## History:
## 
#####################################################################################
rm(list = ls())


## ////////////////////////////////////////////////////////////////////////////
## prep data
## ////////////////////////////////////////////////////////////////////////////

## 1) map only 3 columns: chr, name, position
system(command = "cut -f 1,2,4 ../data/wgas1.map > ../data/wgas2.map")
## same: awk -F " " '{print $1 " " $2 " " $4}' wgas1.map > wgas2.map

## 2) take only the first (ID) and the 5th (sex) column for a datfile (which is only used for
## merging, actually you could put some phenotypes here).
system(command = "cut -f 2,5 -d ' ' ../data/wgas1.ped > ../data/fake_pheno.dat")

tmp <- read.table("../data/fake_pheno.dat")
names(tmp) <- c("id", "sex")
tmp$sex <- tmp$sex - 1 ## sex has to be 0/1 coded (0 = female, 1 = male)
write.table(tmp, file = "../data/fake_pheno2.dat", row.names = FALSE, col.names= TRUE, quote = FALSE)


## 3) ped/map >> raw
library(GenABEL)
convert.snp.ped(
    ped = "../data/wgas1.ped",
    mapfile = "../data/wgas2.map",
    out = "../data/wgas1.raw",
    mapHasHeaderLine = FALSE
    )

dat <- load.gwaa.data(phenofile = "../data/fake_pheno2.dat", genofile = "../data/wgas1.raw", id = "id")

## structure
## -----------
str(dat)

## summary for SNPs
## ---------------------

sm <- summary(dat)
head(sm)


## summary by patient
## ---------------------
sm.pat <- perid.summary(dat)
head(sm.pat)

## extract geno data
## ----------------

tmp <- as.numeric(dat)[,c("rs3094315")]

tmp <- as.numeric(dat)[,c(33:40)]

tmp <- as.numeric(gtdata(dat)[,1:10])



## make up some fake phenotype data
## -------------------------------

n <- length(phdata(dat)$id)
dat.pheno <- data.frame(phdata(dat), y = rnorm(n))
## longitudinal
dat.pheno.l <- data.frame(rbind(phdata(dat), phdata(dat)), y = rnorm(n * 2))

save(dat.pheno, dat.pheno.l, file = "../data/pheno.RData")


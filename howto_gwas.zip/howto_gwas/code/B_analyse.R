#####################################################################################
## Author: Sina Rueeger [sina *.* rueger *a*t* unil *.* ch]
## Project: 
##        
## Time-stamp: <[B_analyse.R] by SR Wed 29/01/2014 11:23 (CET)>
##
## Description:
## 
##
## History:
## 
#####################################################################################
rm(list = ls())
library(multicore)
library(GenABEL)

## ////////////////////////////////////////////////////////////////////////////
## prep data
## ////////////////////////////////////////////////////////////////////////////
load("../data/pheno.RData")
dat <- load.gwaa.data(phenofile = "../data/fake_pheno2.dat", genofile = "../data/wgas1.raw", id = "id")

## structure
## -----------
str(dat)

## summary for SNPs
## ---------------------

sm <- summary(dat)
head(sm)

## only include snps with
## ----------------------

snps <- rownames(sm)[sm$Pexact > 1e-6]
head(snps)

## extract geno data
## ----------------

dat.g <- as.numeric(dat)


## ////////////////////////////////////////////////////////////////////////////
## analysis
## ////////////////////////////////////////////////////////////////////////////


## LINEAR MODEL
## -------------
dat.p <- dat.pheno

wrap.lm <- function(form = formula("y ~ snp + sex"), data)
{
    summary(lm(form, data = data))$coef[2,]
}

res <- mclapply(1:10#length(snps)
                , function(i)
            {
                dat.tmp <- merge(dat.p, data.frame(id = rownames(dat.g), snp =  dat.g[,snps[i]]), by =
                                 "id", all.x = TRUE)
                wrap.lm(data = dat.tmp)
                
            } , mc.cores = 2)

mat <- data.frame(matrix(unlist(res), ncol = 4, byrow = TRUE))
names(mat) <- c("estimate", "se", "tval", "p")


## MIXED EFFECTS MODEL
## ---------------------
library(lme4)

wrap.lmer <- function(form = formula("y ~ snp + sex + (1|id)"), data)
{
    x <- lmer(form, data = data)
    summary(x)$coefficients[2,]    
}

dat.p <- dat.pheno.l

res <- mclapply(1:4#length(snps)
                , function(i)
            {
                dat.tmp <- merge(dat.p, data.frame(id = rownames(dat.g), snp =  dat.g[,snps[i]]), by =
                                 "id", all.x = TRUE)
                ret <- tryCatch(
                    {
                        wrap.lmer(data = dat.tmp)
                    },  error=function(e){cat("ERROR :",conditionMessage(e), "\n")})

                if(is.null(ret))
                    ret <- rep(NA, 3)

                return(ret)
            } , mc.cores = 2)

mat <- data.frame(matrix(unlist(res), ncol = 3, byrow = TRUE))
names(mat) <- c("estimate", "se", "tval")


